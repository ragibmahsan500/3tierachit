import boto3
dynamo = boto3.resource('dynamodb')

def lambda_handler(event,conotext):
    import boto3

    client = boto3.client('dynamodb')
    paginator = client.get_paginator('scan')
    
    for page in paginator.paginate(
            TableName='cars',
            AttributesToGet=[
                'id','make','model','year','type'
            ]
        ):
        print(page)
        return(page)