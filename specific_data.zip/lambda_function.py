import boto3
import json

def lambda_handler(event,conotext):
    import boto3
    ctype = event['pathParameters']['proxy'] 
    print(ctype)
    client = boto3.client('dynamodb')
    
    response = client.scan(
        TableName='cars',
        FilterExpression='cartype = :cartype',
        #KeyConditionExpression='id = :id',
        ExpressionAttributeValues={
            ':cartype': {
                'S': str(ctype)
            }
        }
    )
    print(response)
    return {
        "statusCode": 200, 
        "headers": {'Content-Type': 'application/json'}, 
        "body": json.dumps(response)
    }

